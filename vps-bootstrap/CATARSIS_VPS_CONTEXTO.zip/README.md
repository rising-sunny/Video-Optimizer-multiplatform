# Contexto para el VPS — sin secretos

Este paquete contiene calendario, música, ejemplos del primer día y registros públicos de publicación. No incluye OAuth, .env, claves SSH, credenciales de ChatGPT/GitHub ni tokens de redes.

Destino previsto: /home/videoagent/video-automation. El repo está separado en /home/videoagent/Video-Optimizer-multiplatform.

La extracción debe preservar archivos existentes: comprobar primero el destino y detenerse ante un conflicto. No ejecutar automáticamente scripts de otros paquetes ni activar timers. Este paquete no contiene instaladores ni ejecutables.

Leer AGENT_RUNBOOK.md. calendar.json marca el 16 de octubre como publicado y los otros 29 días como pendientes, sin programador activo. published_day1.json conserva los seis IDs y enlaces públicos; no repetirlos.

music.json incluye enlaces oficiales para descargar las seis pistas y sus créditos. Antes de usar una pista, comprobar disponibilidad/licencia y conservar su evidencia. El autor utiliza Content ID: tener licencia no garantiza ausencia de reclamaciones automáticas.

examples/ contiene los metadatos y las hojas de contactos de los videos ya publicados como referencia visual. No son las producciones de mañana ni deben publicarse de nuevo. El material fuente y las licencias de las imágenes se encuentran en los metadatos y asset_credits.json. No incluye los MP4 ni todos los medios originales.

Tras importar este contexto, el siguiente paso es que Codex prepare un procedimiento reutilizable de generación y QA sin publicar. Las credenciales sociales del VPS, el horario y el timer siguen pendientes de verificación/configuración.
